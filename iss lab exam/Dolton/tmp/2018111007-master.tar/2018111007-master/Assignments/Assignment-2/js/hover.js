function hover(x)
{
	x.style.backgroundColor="blue";
}
function hover2(x)
{
	x.style.backgroundColor="black";
}