function clear() {
  document.getElementById('result').
}

function 1() {
  var res=document.getElementById('result').innerHTML='1';
}
